
from flask import Flask, request, render_template, redirect, url_for
import pandas as pd
import plotly.graph_objects as go
import plotly.subplots as sp
import numpy as np
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

# Ensure upload folder exists
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

# Default thresholds
default_thresholds = {
    'train/box_loss': 1.0,
    'train/cls_loss': 1.0,
    'train/dfl_loss': 0.5,
    'metrics/precision': 0.9,
    'metrics/recall': 0.9,
    'metrics/mAP_0.5': 0.9,
    'metrics/mAP_0.5:0.95': 0.7,
    'val/box_loss': 1.0,
    'val/cls_loss': 1.0,
    'val/dfl_loss': 0.5
}

def determine_bg_color(metric_data, threshold):
    if metric_data.iloc[-1] < threshold:
        return 'lightgreen'
    elif metric_data.iloc[-1] > metric_data.iloc[0]:
        return 'lightcoral'
    else:
        return 'lightyellow'

def calculate_summary_statistics(metric_data):
    mean = np.mean(metric_data)
    median = np.median(metric_data)
    std = np.std(metric_data)
    return f"Mean: {mean:.2f}, Median: {median:.2f}, Std: {std:.2f}"

def create_dashboard(file_path, thresholds):
    data = pd.read_csv(file_path)
    data.columns = data.columns.str.strip()
    fig = sp.make_subplots(rows=5, cols=2, subplot_titles=(
        'Train Box Loss', 'Train Class Loss',
        'Train DFL Loss', 'Metrics Precision',
        'Metrics Recall', 'Metrics mAP_0.5',
        'Metrics mAP_0.5:0.95', 'Val Box Loss',
        'Val Class Loss', 'Val DFL Loss'
    ))

    metrics = [
        'train/box_loss', 'train/cls_loss', 'train/dfl_loss',
        'metrics/precision', 'metrics/recall', 'metrics/mAP_0.5',
        'metrics/mAP_0.5:0.95', 'val/box_loss', 'val/cls_loss',
        'val/dfl_loss'
    ]

    for i, metric in enumerate(metrics):
        row = i // 2 + 1
        col = i % 2 + 1
        metric_data = data[metric]
        bg_color = determine_bg_color(metric_data, thresholds[metric])
        summary_stats = calculate_summary_statistics(metric_data)
        fig.add_trace(go.Scatter(x=data['epoch'], y=metric_data, mode='lines+markers', name=metric, text=summary_stats, hoverinfo='text'), row=row, col=col)
        fig.add_trace(go.Scatter(x=data['epoch'], y=[thresholds[metric]]*len(data), mode='lines', name=f'Very Good ({metric})', line=dict(dash='dash')), row=row, col=col)
        z = np.polyfit(data['epoch'], metric_data, 1)
        p = np.poly1d(z)
        fig.add_trace(go.Scatter(x=data['epoch'], y=p(data['epoch']), mode='lines', name=f'Trend ({metric})', line=dict(dash='dot')), row=row, col=col)
        fig.update_xaxes(row=row, col=col, showgrid=False, zeroline=False)
        fig.update_yaxes(row=row, col=col, showgrid=False, zeroline=False)
        fig.add_vrect(x0=data['epoch'].min(), x1=data['epoch'].max(), fillcolor=bg_color, opacity=0.2, layer="below", line_width=0, row=row, col=col)
    fig.update_layout(height=1500, width=1000, title_text="Interactive Graphs of Training and Validation Metrics")
    return fig.to_html(full_html=False)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)
        if file:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(file_path)
            thresholds = {key: float(request.form.get(key, default_thresholds[key])) for key in default_thresholds.keys()}
            dashboard_html = create_dashboard(file_path, thresholds)
            return render_template('dashboard.html', dashboard_html=dashboard_html, thresholds=thresholds)
    return render_template('index.html', thresholds=default_thresholds)

if __name__ == '__main__':
    app.run(debug=True)
